#ifndef _INIT_PORT
#define _INIT_PORT

#include "epuck_ports.h"
/* functions */
void InitPort(void);
#endif