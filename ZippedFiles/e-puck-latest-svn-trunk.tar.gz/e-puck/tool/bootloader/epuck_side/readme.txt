
tinybld_ds6014A_7.37Mhz_115200uart1_8xPLL_with_LEDs.hex		7.37MHz quartz => 30MIPS, using UART1

only those .hex-s are available for now;
only FlashWrite is implemented now; EEPROM and CFG in the future