
void wait(long num);
int getselector();
