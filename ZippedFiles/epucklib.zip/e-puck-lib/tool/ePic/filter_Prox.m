function [filtered_values]= filter_Prox (values)
% Filter for Proximity sensor values

%filtered_values  = filter_TP_A(values);
filtered_values  = values;